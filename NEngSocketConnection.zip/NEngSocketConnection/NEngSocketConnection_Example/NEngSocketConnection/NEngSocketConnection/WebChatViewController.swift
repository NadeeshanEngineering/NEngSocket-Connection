//
//  WebChatViewController.swift
//  NEngSocketConnection
//
//  Created by Nadeeshan on 6/25/18.
//  Copyright © 2018 NEngineering. All rights reserved.
//

import UIKit

class WebChatViewController: UIViewController, NEngWebSocketDelegate {
    
    // Creating an instance of NEngWebSocketConnection with host and port info
    var socket: NEngWebSocketConnection = NEngWebSocketConnection(host: "localhost", port: 8080)
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputTextView: UITextView!
    @IBOutlet weak var errorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Assigning NEngWebSocketDelegate to NEngWebSocketConnection instance so the new instance can access NEngWebSocketDelegate public functions
        socket.delegate = self
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        socket.terminateSocketConnection()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func sendButtonTouchUpInside(sender: UIButton) {
        
        let userInputText: String = inputTextField.text!
        errorLabel.text = ""
        if userInputText.count > 0 {
            inputTextField.text = ""
            outputTextView.text = "\(outputTextView.text!)Me: \(userInputText)\n"
            
            // Using NEngWebSocketConnection to send message to server
            do {
                try socket.sendMessage(request: "\(userInputText)\n")
            } catch {
                print("error: \(error.localizedDescription)")
                self.errorLabel.text = error.localizedDescription
            }
        }
    }
    
    // MARK: - NEngSocket delegate functions
    func stream(_ aStream: Stream, handle eventCode: Stream.Event) {
        switch eventCode {
        case Stream.Event.openCompleted:
            print("Host Status: Host connection established")
            break
        case Stream.Event.hasBytesAvailable:
            // Read socket respond that send by the server
            let socketResponse = try? socket.readSocketConnection(stream: socket.inputStream())
            if socketResponse != nil {
                print("Host Status: Host has Bytes Available")
                print("respond from server (Web Socket) : \(String(describing: socketResponse!))")
                self.outputTextView.text = "\(self.outputTextView.text!)Server: \(socketResponse!)\n"
            }
            break
        case Stream.Event.errorOccurred:
            print("Host Status: Error Occurred")
            socket.terminateSocketConnection()
            break
        case Stream.Event.endEncountered:
            print("Host Status: End of the Stream")
            break
        default:
            break
        }
    }
}
