//
//  ViewController.swift
//  NEngSocketConnection
//
//  Created by Nadeeshan on 6/25/18.
//  Copyright © 2018 NEngineering. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputTextView: UITextView!
    @IBOutlet weak var errorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func sendButtonTouchUpInside(sender: UIButton) {
        
        let userInputText: String = inputTextField.text!
        errorLabel.text = ""
        if userInputText.count > 0 {
            inputTextField.text = ""
            outputTextView.text = "\(outputTextView.text!)Me: \(userInputText)\n"
            
            // Using NEngSocketConnection to send message to server with completion
            NEngSocketConnection(host: "localhost", port: 8080, timeout: 30000).sendMessageWithCompletion(request: "\(userInputText)\n") {
                (result: Any, error: NSError) in
                
                // Respond: "result" (Any) is the respond that receive from the server
                self.outputTextView.text = "\(self.outputTextView.text!)Server: \(result)\n"
                
                // Error: "error" (NSError) is the exception that receive while Socket Connection crash
                switch error.code {
                    case 404:
                        print("Error: \(error.localizedDescription). Please try again.")
                        self.errorLabel.text = error.localizedDescription
                        break
                    case 408:
                        print("Error: \(error.localizedDescription). Please try again.")
                        self.errorLabel.text = error.localizedDescription
                        break
                    case 503:
                        print("Error: \(error.localizedDescription). Please try again.")
                        self.errorLabel.text = error.localizedDescription
                        break
                    default: break
                }
            }
        }
    }
}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tapGesture = UITapGestureRecognizer(target: self,
                                                action: #selector(hideKeyboard))
        view.addGestureRecognizer(tapGesture)
    }
    
    @objc func hideKeyboard() {
        view.endEditing(true)
    }
}

